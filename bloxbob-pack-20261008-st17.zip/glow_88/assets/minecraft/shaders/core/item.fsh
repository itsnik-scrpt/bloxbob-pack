#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec4 lightMapColor;
in vec4 overlayColor;
in vec2 texCoord0;
in float bloxTintGlow;

out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0);
    // BloxBob glow: texture pixels with alpha exactly 252 are emissive (full bright, no shading or darkness)
    bool bloxGlow = abs(color.a * 255.0 - 252.0) < 0.5 || bloxTintGlow > 0.5;
    if (bloxGlow) color.a = 1.0;
#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
#endif

    color *= (bloxGlow ? vec4(1.0, 1.0, 1.0, vertexColor.a) : vertexColor) * ColorModulator;
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
    if (!bloxGlow) color *= lightMapColor;

    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
