#version 150
#define OC_EMISSIVE_INTENSITY 1.1
#moj_import <minecraft:fog.glsl>
#if defined(PER_FACE_LIGHTING) || !defined(NO_CARDINAL_LIGHTING)
#moj_import <minecraft:light.glsl>
#endif
#moj_import <minecraft:dynamictransforms.glsl>
uniform sampler2D Sampler0;
in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#ifdef PER_FACE_LIGHTING
in vec4 vertexPerFaceColorBack;
in vec4 vertexPerFaceColorFront;
#else
in vec4 vertexColor;
#endif
in vec4 lightColor;
in vec4 overlayColor;
in vec2 texCoord;
in vec2 texCoord2;
in vec3 Pos;
in float transition;
flat in int isCustom;
flat in int noshadow;
flat in vec4 ocTint;
flat in int ocLayerFlags;
flat in float ocEmissMaskV;
flat in float ocTintMaskV;
out vec4 fragColor;
void main() {
#ifndef OC_NO_INVERTED_CUBES
    if (isCustom == 1 && !gl_FrontFacing) discard;
#endif
    vec4 tex = transition > 0.0
        ? mix(texture(Sampler0, texCoord), texture(Sampler0, texCoord2), transition)
        : texture(Sampler0, texCoord);
    // BloxBob glow: texture pixels with alpha exactly 252 are emissive (full bright)
    bool bloxGlow = isCustom == 0 && abs(tex.a * 255.0 - 252.0) < 0.5;
    if (bloxGlow) tex.a = 1.0;
    vec4 color = tex;
    bool ocEmissive = (isCustom == 1) && tex.a > 0.0 && (
        ((ocLayerFlags & 1) != 0) ||
        (ocEmissMaskV > 0.0 && texture(Sampler0, vec2(texCoord.x, texCoord.y + ocEmissMaskV)).a > 0.0)
    );
    bool ocTintable = (isCustom == 1) && tex.a > 0.0 && (
        ((ocLayerFlags & 2) != 0) ||
        (ocTintMaskV  > 0.0 && texture(Sampler0, vec2(texCoord.x, texCoord.y + ocTintMaskV )).a > 0.0)
    );
    vec3 ocBase = ocTintable ? tex.rgb * ocTint.rgb : tex.rgb;
    if (ocTintable) { color.rgb = ocBase; color.a = 1.0; }
    #define ENTITY
    #moj_import<mythicarmors_light.glsl>
    if (bloxGlow) color = vec4(tex.rgb, 1.0) * ColorModulator;
    if (ocEmissive) { color.rgb = ocBase * OC_EMISSIVE_INTENSITY; color.a = 1.0; }
#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) discard;
#endif
#ifndef NO_OVERLAY
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
#endif
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
