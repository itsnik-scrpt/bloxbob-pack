#version 330

#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in vec4 overlayColor;
in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
    fragColor = color;

	// Emissive 
	if (color.a > 0.996 && color.a < 0.997) {
		vec4 emissive = texture(Sampler0, texCoord0) * overlayColor * vec4(ColorModulator.rgb, 1);
		fragColor = vec4(emissive.rgb * 1.1, emissive.a);
	}
}
