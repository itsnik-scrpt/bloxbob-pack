# Credits

## Armor of the Ages
The Titan and Skyward armor sets are based on
[Armor of the Ages](https://github.com/Dawn-of-Time-Project/armoroftheages)
(Holy armor -> Titan, Exalted Aurum -> Skyward), recoloured: the worn 3D helmets are converted models, the other
pieces are the mod's textures wrapped onto vanilla armor, and the inventory icons are its item art.

- Models and textures by **Poulpinou**, armor skins by **TheGoldenWorld** (Dawn of Time).
- Released under the MIT License: see `licenses/armor-of-the-ages-LICENSE.txt` (copyright (c) 2023 Pierre C).
- Converted with `tools/make_set_helmets.py`, `tools/make_set_armor.py` and `tools/import_aota_helmets.py`.
